#include "stdafx.h"
#include "totalScoreUi.h"

totalScoreUi::totalScoreUi(string name, POINTFLOAT pos, POINTFLOAT size, Pivot pivot)
	:GameObject(name, pos, size, pivot)
{
}

totalScoreUi::~totalScoreUi()
{
}

HRESULT totalScoreUi::init(void)
{
	return S_OK;
}

void totalScoreUi::release(void)
{
}

void totalScoreUi::update(void)
{
}

void totalScoreUi::render()
{
}
