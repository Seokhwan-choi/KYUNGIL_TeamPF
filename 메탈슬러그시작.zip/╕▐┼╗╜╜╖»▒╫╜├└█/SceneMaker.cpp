#include "stdafx.h"
#include "SceneMaker.h"

HRESULT SceneMaker::Init(void)
{
	return S_OK;
}

void SceneMaker::Release(void)
{

}

void SceneMaker::Update(void)
{

}

void SceneMaker::Render(void)
{

}